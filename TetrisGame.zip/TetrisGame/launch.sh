#!/bin/sh
./TetrisRuntime/bin/java -jar TetrisGame.jar
